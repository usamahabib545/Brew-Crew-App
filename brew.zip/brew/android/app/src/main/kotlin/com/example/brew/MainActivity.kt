package com.example.brew

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
